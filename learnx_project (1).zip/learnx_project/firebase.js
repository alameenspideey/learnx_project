// firebase.js
if (!firebase.apps.length) {
  var firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "learnx-a3c27.firebaseapp.com",
    projectId: "learnx-a3c27",
    storageBucket: "learnx-a3c27.appspot.com",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
  };

  firebase.initializeApp(firebaseConfig);
}

var auth = firebase.auth();
var db = firebase.firestore();