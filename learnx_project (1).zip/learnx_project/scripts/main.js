// scripts/main.js

// Progress Tracking
function markProgress() {
  const progressBar = document.getElementById('courseProgress');
  const progressText = document.getElementById('progressText');
  let currentProgress = parseInt(progressBar.value);

  if (currentProgress < 100) {
    currentProgress += 25;
    if (currentProgress > 100) currentProgress = 100;

    progressBar.value = currentProgress;
    progressText.textContent = `${currentProgress}%`;
  }
}

// Quiz Submission
document.addEventListener('DOMContentLoaded', function () {
  const quizForm = document.getElementById('quizForm');

  if (quizForm) {
    quizForm.addEventListener('submit', function (e) {
      e.preventDefault();

      let score = 0;
      const q1 = document.querySelector('input[name="q1"]:checked');
      const q2 = document.querySelector('input[name="q2"]:checked');

      if (q1 && q1.value === 'a') score++;
      if (q2 && q2.value === 'b') score++;

      document.getElementById('quizResult').innerHTML = `<h3>Your Score: ${score}/2</h3>`;

      const user = firebase.auth().currentUser;
      if (user) {
        db.collection('users').doc(user.uid).set({
          quizScores: score
        }, { merge: true });
      }
    });
  }
});

function signup() {
  const email = document.getElementById('signupEmail').value;
  const password = document.getElementById('signupPassword').value;

  firebase.auth().createUserWithEmailAndPassword(email, password)
    .then((userCredential) => {
      userCredential.user.sendEmailVerification()
        .then(() => {
          alert('Signup successful! Verification email sent. Please verify before logging in.');
          window.location.href = 'login.html';
        });
    })
    .catch((error) => {
      alert(error.message);
    });
}

function login() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  firebase.auth().signInWithEmailAndPassword(email, password)
    .then((userCredential) => {
      if (userCredential.user.emailVerified) {
        alert('Login Successful!');
        window.location.href = 'dashboard.html';
      } else {
        firebase.auth().signOut();
        alert('Please verify your email before logging in.');
      }
    })
    .catch((error) => {
      alert(error.message);
    });
}

function markProgress() {
  const progressBar = document.getElementById('courseProgress');
  const progressText = document.getElementById('progressText');
  let currentProgress = parseInt(progressBar.value);

  if (currentProgress < 100) {
    currentProgress += 25;
    if (currentProgress > 100) currentProgress = 100;

    progressBar.value = currentProgress;
    progressText.textContent = `${currentProgress}%`;

    // Save progress to Firestore
    const user = firebase.auth().currentUser;
    if (user) {
      db.collection('users').doc(user.uid).set({
        progress: currentProgress
      }, { merge: true });
    }
  }
}